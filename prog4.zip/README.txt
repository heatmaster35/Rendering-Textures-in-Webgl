The objects that work with my code are in order as
object1 --> fireplace.coor/.poly
object2 --> cube.coor/.poly.
some of the files give errors, but these should work.
also, both of the objects rotate,scale, and translate(x,y,and z-axis.
camera zooms, translates on z-axis, and rotates.


instructions:

scroll wheel to zoom(no buttons pressed)
click middle button on background switch between zoom and tranlation of z-axis(scroll with no buttons pressed)

hold left click on object to translate
hold right click on object to rotate it
hold middle click on object to scale(move up or down on the mouse)

hold left click on background to translate camera
hold right click on background to rotate camera
hold middle click on object to translate on z-axis(hold middle button and scroll wheel)

the color sliders do not work(the colors are preset).
the translate is alittle weird. the fireplace moves fast,
while the cube moves slow so you have to drag alot more for the cube!
translation on the z-axis for objects works!

also:

I tried implemeting textures, but i couldn't find a way to get
past the security error. i commented out the line for the
image. but to recreate the security error, take out the "//"
parts from lines 1049 and 1050. but i did fix my face normals
and vertex normals, but ran out of time.

